<?php
$conn=mysqli_connect("localhost","id4020783_userdata","Magic@30","id4020783_magicprint");
if(!$conn)
{  
  mysqli_error();
  die();
}
?>